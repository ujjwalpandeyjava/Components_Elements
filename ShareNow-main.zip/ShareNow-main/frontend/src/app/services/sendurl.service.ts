import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SendurlService {

  constructor() { }

  link?:string;
}
